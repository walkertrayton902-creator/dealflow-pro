import { ensurePostgresSchema, storageMode, closePersistence } from '../lib/persistence.mjs'
try { await ensurePostgresSchema(); console.log(`DealFlow migrations complete (${storageMode()})`) }
finally { await closePersistence() }
