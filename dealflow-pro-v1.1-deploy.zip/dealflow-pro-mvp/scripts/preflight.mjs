const required = [
  ['APP_ORIGIN','Public HTTPS origin, e.g. https://dealflowpro.onrender.com'],
  ['DATABASE_URL','Production PostgreSQL connection string'],
  ['OPENAI_API_KEY','Deal AI API key'],
  ['ADMIN_EMAILS','Comma-separated admin email list'],
]
const recommended = [
  ['S3_BUCKET','Private object storage bucket'],
  ['S3_ACCESS_KEY_ID','Object storage access key'],
  ['S3_SECRET_ACCESS_KEY','Object storage secret'],
  ['GOOGLE_CLIENT_ID','Gmail OAuth client ID'],
  ['GOOGLE_CLIENT_SECRET','Gmail OAuth client secret'],
  ['GOOGLE_REDIRECT_URI','Gmail OAuth callback URL'],
  ['STRIPE_SECRET_KEY','Stripe secret key'],
  ['STRIPE_PRICE_STARTER','Stripe Starter price ID'],
  ['STRIPE_PRICE_PRO','Stripe Pro price ID'],
]
const missingRequired = required.filter(([k])=>!process.env[k])
const missingRecommended = recommended.filter(([k])=>!process.env[k])
console.log('DealFlow Pro production preflight')
console.log('--------------------------------')
for (const [k,desc] of required) console.log(`${process.env[k]?'✓':'✗'} ${k} — ${desc}`)
for (const [k,desc] of recommended) console.log(`${process.env[k]?'✓':'!'} ${k} — ${desc}`)
console.log('')
if (process.env.APP_ORIGIN && !/^https:\/\//i.test(process.env.APP_ORIGIN)) console.warn('! APP_ORIGIN should use HTTPS in production.')
if (process.env.GOOGLE_REDIRECT_URI && process.env.APP_ORIGIN && !process.env.GOOGLE_REDIRECT_URI.startsWith(process.env.APP_ORIGIN)) console.warn('! GOOGLE_REDIRECT_URI does not start with APP_ORIGIN.')
if (missingRequired.length) {
  console.error(`BLOCKED: ${missingRequired.length} required production setting(s) missing: ${missingRequired.map(x=>x[0]).join(', ')}`)
  process.exit(1)
}
console.log(missingRecommended.length ? `READY FOR CORE BETA, but ${missingRecommended.length} optional/recommended integration setting(s) are still missing.` : 'READY: all checked production settings are present.')
