import fs from 'node:fs'
import path from 'node:path'
import { createPersistence, ensurePostgresSchema, closePersistence } from '../lib/persistence.mjs'
import { createBlobStorage } from '../lib/blob-storage.mjs'

if(!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required for legacy import')
const dataDir=path.resolve(process.env.DATA_DIR||'./data')
const uploadDir=path.resolve(process.env.UPLOAD_DIR||'./uploads')
const dbPath=path.join(dataDir,'db.json')
if(!fs.existsSync(dbPath)) throw new Error(`Legacy database not found: ${dbPath}`)
const legacy=JSON.parse(fs.readFileSync(dbPath,'utf8'))
await ensurePostgresSchema()
const { writeDB }=createPersistence({dbPath,seed:{}})
await writeDB(legacy)

if(process.env.S3_BUCKET){
  const blobs=createBlobStorage(uploadDir)
  let moved=0
  for(const doc of legacy.documents||[]){
    if(!doc.storedName) continue
    const candidates=[path.join(uploadDir,doc.storedName),path.join(uploadDir,path.basename(doc.storedName))]
    const found=candidates.find(fs.existsSync)
    if(!found) continue
    const key=doc.storedName.includes('/')?doc.storedName:`legacy/${doc.dealId}/${doc.storedName}`
    await blobs.put(key,fs.readFileSync(found),'application/octet-stream')
    doc.storedName=key
    moved++
  }
  if(moved) await writeDB(legacy)
  console.log(`Imported ${moved} legacy document files into object storage.`)
}
console.log(`Imported legacy data: ${(legacy.users||[]).length} users, ${(legacy.deals||[]).length} deals, ${(legacy.documents||[]).length} documents.`)
await closePersistence()
