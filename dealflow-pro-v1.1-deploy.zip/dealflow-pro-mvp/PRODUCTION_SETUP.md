# DealFlow Pro — Production Setup Order

Use this order for the first live beta deployment.

## 1. Database
Create a production PostgreSQL database and set `DATABASE_URL`.
Run:

```bash
npm run migrate
```

## 2. Private document storage
Create a private S3-compatible bucket and set:

- `S3_BUCKET`
- `S3_REGION`
- `S3_ENDPOINT` when required by the provider
- `S3_ACCESS_KEY_ID`
- `S3_SECRET_ACCESS_KEY`
- `S3_FORCE_PATH_STYLE` when required

Do not make the bucket public. DealFlow serves documents through authenticated API routes.

## 3. OpenAI
Set `OPENAI_API_KEY` and keep `OPENAI_MODEL=gpt-5.6-luna` for the cost-sensitive beta default.
The key must only exist on the server; never expose it to the browser bundle.

## 4. Deploy the web service
Deploy the repository using the included `Dockerfile` / `render.yaml`.
Set `APP_ORIGIN` to the final HTTPS URL.

Before starting the service, run:

```bash
npm run preflight
npm run migrate
```

## 5. Gmail OAuth
In Google Cloud, create an OAuth web client. Configure the exact redirect URL:

`https://YOUR-LIVE-DOMAIN/api/email/google/callback`

Then set:

- `GOOGLE_CLIENT_ID`
- `GOOGLE_CLIENT_SECRET`
- `GOOGLE_REDIRECT_URI`

The current beta requests Gmail read-only plus send scopes. Google may require OAuth consent configuration/verification before broad public use.

## 6. Stripe
Create Starter and Pro recurring prices and set:

- `STRIPE_SECRET_KEY`
- `STRIPE_PRICE_STARTER`
- `STRIPE_PRICE_PRO`

Test Checkout and Billing Portal in Stripe test mode before enabling live mode.

## 7. Admin account
Set `ADMIN_EMAILS` to the email address(es) allowed into the beta admin dashboard.

## 8. Final smoke test
Verify this exact flow on the live HTTPS URL:

1. Register
2. Complete onboarding
3. Create a deal
4. Save underwriting
5. Upload a document
6. Run document analysis
7. Ask Deal AI
8. Create an investor share
9. Generate an LOI
10. Connect Gmail and sync a test thread
11. Complete a Stripe test checkout
12. Log out and confirm the session is invalidated

## Production rule
Never paste production secrets into chat, source control, screenshots, or client-side code. Enter them only into the hosting provider's secret/environment-variable controls.
