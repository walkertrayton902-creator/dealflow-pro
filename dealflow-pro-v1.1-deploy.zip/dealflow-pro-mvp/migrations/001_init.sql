create table if not exists users (
  id bigint primary key,
  email text not null unique,
  payload jsonb not null
);
create table if not exists sessions (
  token text primary key,
  user_id bigint references users(id) on delete cascade,
  payload jsonb not null
);
create table if not exists deals (
  id bigint primary key,
  user_id bigint references users(id) on delete cascade,
  payload jsonb not null
);
create index if not exists deals_user_idx on deals(user_id);
create table if not exists analyses (
  deal_id bigint primary key references deals(id) on delete cascade,
  payload jsonb not null
);
create table if not exists documents (
  id bigint primary key,
  deal_id bigint not null references deals(id) on delete cascade,
  payload jsonb not null
);
create index if not exists documents_deal_idx on documents(deal_id);
create table if not exists messages (
  id bigint primary key,
  deal_id bigint not null references deals(id) on delete cascade,
  payload jsonb not null
);
create index if not exists messages_deal_idx on messages(deal_id);
create table if not exists due_tasks (
  id bigint not null,
  deal_id bigint not null references deals(id) on delete cascade,
  payload jsonb not null,
  primary key(deal_id,id)
);
create table if not exists scenarios (
  id bigint not null,
  deal_id bigint not null references deals(id) on delete cascade,
  payload jsonb not null,
  primary key(deal_id,id)
);
create table if not exists investor_shares (
  token text primary key,
  deal_id bigint not null references deals(id) on delete cascade,
  payload jsonb not null
);
create table if not exists offers (
  id bigint not null,
  deal_id bigint not null references deals(id) on delete cascade,
  payload jsonb not null,
  primary key(deal_id,id)
);
create table if not exists email_connections (
  user_id bigint primary key references users(id) on delete cascade,
  payload jsonb not null
);
create table if not exists oauth_states (
  state text primary key,
  user_id bigint not null references users(id) on delete cascade,
  payload jsonb not null
);
create table if not exists leads (
  id bigint primary key,
  user_id bigint references users(id) on delete cascade,
  payload jsonb not null
);
create index if not exists leads_user_idx on leads(user_id);
create table if not exists saved_searches (
  id bigint primary key,
  user_id bigint references users(id) on delete cascade,
  payload jsonb not null
);
create table if not exists outreach_campaigns (
  id bigint primary key,
  user_id bigint references users(id) on delete cascade,
  payload jsonb not null
);

create table if not exists feedback (
  id bigint primary key,
  user_id bigint references users(id) on delete set null,
  payload jsonb not null
);
create table if not exists client_errors (
  id bigint primary key,
  user_id bigint references users(id) on delete set null,
  payload jsonb not null
);
create index if not exists feedback_user_idx on feedback(user_id);
create index if not exists client_errors_user_idx on client_errors(user_id);
