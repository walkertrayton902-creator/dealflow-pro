# DealFlow Pro v1.0 Beta Launch Checklist

## 1. Required production services
- PostgreSQL database (`DATABASE_URL`)
- Private S3-compatible bucket for deal documents
- HTTPS application URL (`APP_ORIGIN`)

## 2. Recommended integrations
- OpenAI API key for full Deal AI and contextual document analysis
- Google OAuth credentials for Gmail sync/send
- Stripe secret key plus Starter/Pro recurring price IDs for paid subscriptions

## 3. Owner/admin setup
Set `ADMIN_EMAILS` to a comma-separated list of trusted operator emails. Those accounts see the Beta Admin workspace containing aggregate product counts, subscription mix, beta feedback, and captured frontend errors.

## 4. Stripe beta billing
Create two recurring monthly prices in Stripe and set:
- `STRIPE_PRICE_STARTER`
- `STRIPE_PRICE_PRO`

Checkout is hosted by Stripe. DealFlow verifies the returned Checkout Session before changing the account plan. The Account & Billing screen can also sync the latest subscription status and open Stripe's Billing Portal.

For a larger public launch, add a signed Stripe webhook for real-time renewal/cancellation changes rather than relying primarily on return-page verification and manual sync.

## 5. Google/Gmail
Add the production redirect URI shown in `.env.example` to the Google OAuth client. Review Google's production verification requirements before opening Gmail access to the public.

## 6. Legal before public sale
The included Beta Terms and Privacy pages are product placeholders. Have qualified counsel review and finalize:
- Terms of Use
- Privacy Policy
- AI/document disclaimer language
- Investment/securities language around investor-sharing features
- Data retention/deletion policy
- OAuth privacy disclosures

## 7. Beta operating procedure
Start with a small invited cohort. Ask each tester to run one real acquisition workflow from lead import through underwriting and due diligence. Review the Admin dashboard regularly for errors and feedback.

## 8. Pre-public-launch engineering
Before broad scale:
- replace the current full-state PostgreSQL compatibility writes with row-level transactional operations
- add automated integration tests and CI/CD
- add signed Stripe webhooks
- add managed error monitoring/alerting
- add transactional email for account verification/password reset
- add account deletion/data export workflows
- add backups with restore drills
- perform a security review and dependency vulnerability scan
