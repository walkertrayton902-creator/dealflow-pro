# DealFlow Pro v1.0 Beta

DealFlow Pro is an AI-assisted real-estate acquisition operating system built around one workflow: **from finding the deal to getting the keys**.

## v1.0 beta includes
- account registration/login and investor onboarding
- deal sourcing, lead scoring and saved buy boxes
- bulk acquisition outreach with Gmail-ready workflows
- Deal Rooms and acquisition pipeline
- live underwriting and financing scenarios
- document upload + P&L/T-12/rent-roll intelligence
- contextual Deal AI
- investor share pages
- LOI generation
- due-diligence tracking
- PostgreSQL persistence and S3-compatible private document storage
- Starter/Pro subscription UI with Stripe Checkout + Billing Portal hooks
- beta feedback capture and frontend error reporting
- admin-only beta telemetry dashboard
- beta Terms and Privacy pages

## Local run

```bash
npm install
npm run dev
```

In another terminal:

```bash
npm run api
```

Vite normally runs on `http://localhost:5173` and the API on port `8787`.

## Production
See `DEPLOYMENT.md`, `INFRASTRUCTURE.md`, `.env.example`, and `BETA_LAUNCH.md`.

Important: the app can run locally without Stripe, Gmail, OpenAI, PostgreSQL, or S3, but those integrations require their corresponding environment variables for production behavior.

## Beta limitations
This is a beta launch codebase, not a claim of production readiness at unlimited scale. In particular, the PostgreSQL compatibility adapter still performs serialized full-state writes. That is acceptable for a small beta but should be replaced with direct row-level transactional queries before high concurrency.
