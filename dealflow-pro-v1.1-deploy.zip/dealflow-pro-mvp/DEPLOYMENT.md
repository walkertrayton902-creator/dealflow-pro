# DealFlow Pro v0.8 — Deployment Guide

This version is packaged to run the React frontend and Node API from one web service.

## Fastest hosted path: Render + persistent disk

1. Put this project in a private GitHub repository.
2. In Render, create a Blueprint from `render.yaml` or create a Docker Web Service manually.
3. Attach a persistent disk mounted at `/var/lib/dealflow`.
4. Set these environment variables:
   - `APP_ORIGIN=https://YOUR-DOMAIN`
   - `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` if Gmail is enabled
   - `GOOGLE_REDIRECT_URI=https://YOUR-DOMAIN/api/email/google/callback`
   - `OPENAI_API_KEY` if live Deal AI is enabled
5. In Google Cloud OAuth settings, add the same HTTPS Gmail callback URI.
6. Deploy. Render should use `/api/health` for health checks.

## Docker locally

```bash
docker build -t dealflow-pro .
docker run --rm -p 8787:8787 \
  -e APP_ORIGIN=http://localhost:8787 \
  -v dealflow-data:/var/lib/dealflow \
  dealflow-pro
```

Open `http://localhost:8787`.

## Security improvements in v0.8

- 30-day expiring authenticated sessions
- logout invalidates the current session server-side
- production CORS restricted to `APP_ORIGIN`
- security headers on API/static responses
- login/register rate limiting
- outbound-email rate limiting
- uploaded documents are no longer publicly exposed by filename
- authenticated document download route
- atomic JSON state writes
- production API errors do not expose internal exception text

## Storage note

v0.8 deliberately keeps the prototype's JSON application store so the product can be deployed immediately on one persistent web-service instance. The mounted disk keeps accounts, deals, communications and uploaded files across deploys/restarts.

Before running multiple server instances or handling meaningful customer volume, migrate the JSON state to PostgreSQL and uploaded documents to object storage (for example S3/Supabase Storage). Do not horizontally scale the JSON-backed version because concurrent instances could overwrite each other's state.

## Production checklist before public launch

- Use a private source repository.
- Use HTTPS only.
- Set a single exact `APP_ORIGIN`.
- Keep all API/OAuth secrets in host environment settings, never in frontend code.
- Configure Google OAuth production consent/publishing requirements.
- Back up `/var/lib/dealflow` on a schedule.
- Test account recovery before charging users.
- Add Terms of Service and Privacy Policy.
- Add monitoring/error reporting.
- Add transactional email for verification/password reset.
- Move persistence to PostgreSQL/object storage before multi-instance scaling.
