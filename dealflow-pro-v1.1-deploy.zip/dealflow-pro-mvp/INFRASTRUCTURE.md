# DealFlow Pro v0.9 Infrastructure

## What changed

v0.9 supports two persistence modes without changing the frontend API:

- **Local development:** JSON file + local upload directory.
- **Hosted beta/production:** PostgreSQL + private S3-compatible object storage.

The `/api/health` response reports the active database and blob-storage modes.

## PostgreSQL

Set `DATABASE_URL`, then run:

```bash
npm run migrate
```

DealFlow creates separate relational tables for users, sessions, deals, analyses, documents, messages, due-diligence tasks, financing scenarios, investor shares, offers, Gmail connections, OAuth states, leads, saved searches, and outreach campaigns. Foreign keys cascade deal/user cleanup and indexes cover the main user/deal lookups.

The current v0.9 compatibility adapter intentionally preserves the v0.8 API and in-memory domain shape. It serializes state writes with a PostgreSQL advisory transaction lock. This is appropriate for the beta stage, but high-volume production should move hot endpoints to row-level repository methods rather than flushing the complete state on each write.

## Object storage

Set `S3_BUCKET` and the provider settings. The bucket should remain **private**. DealFlow does not expose raw public object URLs; authenticated document downloads are proxied through the app.

Supported S3-compatible targets include AWS S3, Cloudflare R2, Backblaze B2 S3, and MinIO, depending on endpoint/region configuration.

When `S3_BUCKET` is not configured, files remain in `UPLOAD_DIR` for easy local development.

## Moving an existing v0.8 install

Back up `data/` and `uploads/`, configure `DATABASE_URL` and (optionally) S3 variables, then run:

```bash
npm run migrate
npm run import:legacy
```

The legacy importer copies the JSON state into PostgreSQL. If S3 is configured, it also uploads locally stored deal documents and updates their storage keys.

## Recommended hosted topology

- One DealFlow web/API service
- Managed PostgreSQL
- Private S3-compatible bucket
- HTTPS at the platform/load-balancer layer
- `APP_ORIGIN` set to the exact public HTTPS origin
- Secrets stored only in the host's encrypted environment-variable manager

## Backups

With PostgreSQL enabled, use your managed provider's point-in-time recovery or daily snapshots. For object storage, enable provider versioning/lifecycle protection where available. The old `backup.sh` remains useful only for local JSON/disk mode.
