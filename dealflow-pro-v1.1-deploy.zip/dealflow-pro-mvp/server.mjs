import http from 'node:http'
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'
import os from 'node:os'
import { createPersistence, ensurePostgresSchema, storageMode } from './lib/persistence.mjs'
import { createBlobStorage, blobStorageMode } from './lib/blob-storage.mjs'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const dataDir = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(__dirname, 'data')
const uploadDir = process.env.UPLOAD_DIR ? path.resolve(process.env.UPLOAD_DIR) : path.join(__dirname, 'uploads')
const distDir = path.join(__dirname, 'dist')
const isProd = process.env.NODE_ENV === 'production'
const appOrigin = process.env.APP_ORIGIN || (isProd ? '' : 'http://localhost:5173')
const dbPath = path.join(dataDir, 'db.json')
fs.mkdirSync(dataDir, { recursive: true })
fs.mkdirSync(uploadDir, { recursive: true })

const starterDue = ['T-12 / P&L','Rent roll / site list','Utility history','Property taxes','Insurance quote','Zoning / permitted use','Title review','Inspection','Survey','Vendor contracts']
const seed = {
  users: [], sessions: {},
  deals: [
    {id:1,userId:null,name:'Westside RV Park',location:'Oklahoma',type:'RV Park',asking:850000,units:36,gross:236000,expenses:124000,status:'Negotiating',seller:'Owner / Seller',nextAction:'Compare a lower-down seller-finance counter with private-money funding.'},
    {id:2,userId:null,name:'Hilltop Trails RV Park',location:'Missouri',type:'RV Park',asking:725000,units:28,gross:198000,expenses:109000,status:'Financials Requested',seller:'Broker',nextAction:'Review the latest P&L and confirm utility expense history.'},
    {id:3,userId:null,name:'3600 Grand Ave',location:'Parsons, KS',type:'Single-Family',asking:70000,units:1,gross:12000,expenses:3600,status:'Analyzing',seller:'Listing Agent',nextAction:'Finish underwriting and compare owner-occupant versus rental scenarios.'}
  ],
  analyses: {"1":{price:850000,down:50000,rate:5,amortYears:25,gross:236000,expenses:124000,vacancy:5}},
  documents: [],
  messages: [],
  due: {"1": starterDue.map((name,i)=>({id:i+1,name,done:i<2}))},
  scenarios: {"1":[
    {id:1,name:'Seller Finance',down:50000,rate:5,years:25,note:'Lower upfront cash; negotiate amortization and balloon.'},
    {id:2,name:'Private Money + Seller Carry',down:15000,rate:8,years:25,note:'Use private capital for required cash while seller carries the balance.'}
  ]},
  investorShares: {}, offers: {}, emailConnections: {}, oauthStates: {},
  leads: [], savedSearches: [], outreachCampaigns: [], feedback: [], clientErrors: []
}
if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify(seed, null, 2))
await ensurePostgresSchema()
const { readDB, writeDB } = createPersistence({ dbPath, seed })
const blobStore = createBlobStorage(uploadDir)
const securityHeaders = {
  'X-Content-Type-Options':'nosniff',
  'X-Frame-Options':'DENY',
  'Referrer-Policy':'strict-origin-when-cross-origin',
  'Permissions-Policy':'camera=(), microphone=(), geolocation=()',
  'Cross-Origin-Opener-Policy':'same-origin'
}
const corsOrigin = reqOrigin => {
  if(!isProd) return reqOrigin || '*'
  if(!appOrigin) return ''
  return reqOrigin === appOrigin ? appOrigin : ''
}
const send = (res,status,data,headers={},reqOrigin='') => {const origin=corsOrigin(reqOrigin);res.writeHead(status, {'Content-Type':'application/json',...(origin?{'Access-Control-Allow-Origin':origin}:{}),'Vary':'Origin','Access-Control-Allow-Headers':'Content-Type,Authorization','Access-Control-Allow-Methods':'GET,POST,PUT,PATCH,DELETE,OPTIONS',...securityHeaders,...headers});res.end(JSON.stringify(data))}
const rateBuckets=new Map()
const rateLimit=(req,key,limit=30,windowMs=60_000)=>{const ip=(req.headers['x-forwarded-for']||req.socket.remoteAddress||'unknown').toString().split(',')[0].trim();const now=Date.now(),bucketKey=`${key}:${ip}`,old=rateBuckets.get(bucketKey);if(!old||now-old.start>windowMs){rateBuckets.set(bucketKey,{start:now,count:1});return true}old.count+=1;return old.count<=limit}
const body = req => new Promise((resolve,reject)=>{let raw='';req.on('data',c=>{raw+=c;if(raw.length>15_000_000){reject(new Error('Upload too large'));req.destroy()}});req.on('end',()=>{try{resolve(raw?JSON.parse(raw):{})}catch(e){reject(e)}})})
const hashPassword = (password,salt=crypto.randomBytes(16).toString('hex')) => ({salt,hash:crypto.scryptSync(password,salt,64).toString('hex')})
const makeToken=()=>crypto.randomBytes(32).toString('hex')
const sessionToken=req=>(req.headers.authorization||'').replace(/^Bearer\s+/i,'')
const userFromReq=(req,db)=>{const token=sessionToken(req),session=db.sessions?.[token];if(!session)return null;const uid=typeof session==='object'?session.userId:session;if(typeof session==='object'&&session.expiresAt&&Date.now()>session.expiresAt){delete db.sessions[token];return null}return db.users?.find(u=>u.id===uid)||null}
const createSession=(db,userId)=>{const token=makeToken();db.sessions[token]={userId,createdAt:Date.now(),expiresAt:Date.now()+30*24*60*60*1000};return token}
const isAdmin=u=>!!u&&String(process.env.ADMIN_EMAILS||'').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean).includes(String(u.email||'').toLowerCase())
const safeUser=u=>u?({id:u.id,name:u.name,email:u.email,plan:u.plan||'beta',subscriptionStatus:u.subscriptionStatus||'active',onboardingComplete:!!u.onboardingComplete,experienceLevel:u.experienceLevel||'',investmentGoals:u.investmentGoals||[],markets:u.markets||'',admin:isAdmin(u)}):null
const ownsDeal=(deal,user)=>!deal.userId || (user && deal.userId===user.id)
const sanitizeName=n=>String(n||'upload').replace(/[^a-zA-Z0-9._-]/g,'_')


const outreachStage = (direction, text, current='New Lead') => {
  const t=String(text||'').toLowerCase()
  if(direction==='Outbound'){
    if(/t-12|p&l|profit.?loss|rent roll|financials|operating statement/.test(t)) return 'Financials Requested'
    if(/offer|counter|terms|seller financ|owner financ|down payment|interest rate|balloon/.test(t) && current!=='New Lead') return 'Negotiating'
    return current==='New Lead'||current==='Drafted' ? 'Contacted' : current
  }
  if(/not interested|no thanks|sold|under contract/.test(t)) return 'Closed / Not Pursuing'
  if(/financial|p&l|t-12|rent roll|sending|attached/.test(t)) return 'Analyzing'
  if(/interested|open to|let's talk|lets talk|call me|discuss|would consider|may consider/.test(t)) return 'Interested'
  if(/counter|terms|price|down payment|seller financ|owner financ|interest|balloon/.test(t)) return 'Negotiating'
  return current==='Contacted' ? 'Interested' : current
}
const personalizeOutreach = (lead, goal='Introduce me and ask whether the seller is open to discussing terms.') => {
  const first = String(lead.seller||'').trim().split(/\s+/)[0] || 'there'
  const property = lead.title || 'the property'
  const clues = sellerFinanceClues(`${lead.description||''} ${lead.financingNotes||''}`).hits
  const financeLine = clues.length ? 'I also noticed the listing may have some flexibility around terms, so I wanted to ask about that directly.' : 'I would also be interested in understanding whether there is any flexibility on price or financing terms.'
  return `Hi ${first},\n\nI’m reaching out about ${property}${lead.location?` in ${lead.location}`:''}. I’m actively looking at acquisitions like this and would like to learn more about the property and the seller’s goals. ${financeLine}\n\n${goal}\n\nIf it makes sense, I’d be glad to keep this simple and work around the seller’s preferred timeline.\n\nThanks,`
}
const campaignStats = c => ({
  total:c.items?.length||0,
  drafted:(c.items||[]).filter(i=>i.status==='Drafted').length,
  sent:(c.items||[]).filter(i=>i.status==='Sent'||i.status==='Replied').length,
  replied:(c.items||[]).filter(i=>i.status==='Replied').length,
  followUpsDue:(c.items||[]).filter(i=>i.followUpAt&&new Date(i.followUpAt)<=new Date()&&i.status==='Sent').length
})

const sellerFinanceClues = text => {
  const t=String(text||'').toLowerCase(); const hits=[]
  const rules=[['seller financing',18],['owner financing',18],['seller carry',16],['owner carry',16],['terms available',10],['motivated seller',8],['price reduced',6],['reduced price',6],['bring offers',5],['contract for deed',12],['land contract',12],['subject to',10],['assumable',8],['balloon',4]]
  let score=0; for(const [phrase,pts] of rules){if(t.includes(phrase)){hits.push(phrase);score+=pts}}
  return {score:Math.min(60,score),hits}
}
const leadFit = lead => {
  let score=30; const reasons=[]; const clues=sellerFinanceClues(`${lead.title||''} ${lead.description||''} ${lead.financingNotes||''}`); score+=clues.score
  if(Number(lead.price)>0){score+=5; reasons.push('Asking price captured')}
  if(Number(lead.gross)>0){score+=10; reasons.push('Income data available')}
  if(Number(lead.expenses)>0){score+=10; reasons.push('Expense data available')}
  if(Number(lead.units)>1){score+=5; reasons.push('Multi-unit/site property')}
  if(clues.hits.length) reasons.push(`Creative-finance clues: ${clues.hits.join(', ')}`)
  return {score:Math.min(100,score),reasons,clues:clues.hits}
}

const numberFrom = value => {
  if(value===null||value===undefined) return null
  const cleaned=String(value).replace(/[$,%\s,]/g,'').replace(/\(([^)]+)\)/,'-$1')
  const n=Number(cleaned)
  return Number.isFinite(n)?n:null
}
const findMoney = (text,labels=[]) => {
  const escaped=labels.map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|')
  if(!escaped) return null
  const patterns=[
    new RegExp(`(?:${escaped})\\s*[,;:\\-\\t]?\\s*\\$?\\(?([0-9][0-9,]*(?:\\.[0-9]+)?)\\)?`,'i'),
    new RegExp(`\\$?\\(?([0-9][0-9,]*(?:\\.[0-9]+)?)\\)?\\s*(?:${escaped})`,'i')
  ]
  for(const re of patterns){const m=text.match(re);if(m){const n=numberFrom(m[1]);if(n!==null)return n}}
  return null
}
const summarizeTextLocally=(text,type='Other')=>{
  const clean=String(text||'').replace(/\r/g,'').slice(0,180000)
  const lower=clean.toLowerCase()
  const gross=findMoney(clean,['gross revenue','gross income','total revenue','total income','rental income'])
  const expenses=findMoney(clean,['total operating expenses','operating expenses','total expenses','expenses'])
  const noi=findMoney(clean,['net operating income','noi'])
  const occupancy=findMoney(clean,['occupancy','occupied'])
  const rent=findMoney(clean,['monthly rent','site rent','average rent','rent'])
  const units=findMoney(clean,['total sites','sites','units','spaces'])
  const fields={}
  if(gross!==null)fields.gross=gross
  if(expenses!==null)fields.expenses=expenses
  if(noi!==null)fields.noi=noi
  if(occupancy!==null && occupancy<=100)fields.occupancy=occupancy
  if(rent!==null)fields.rent=rent
  if(units!==null && units<100000)fields.units=Math.round(units)
  const warnings=[]
  if(gross!==null&&expenses!==null&&noi!==null){const calc=gross-expenses;if(Math.abs(calc-noi)>Math.max(1000,Math.abs(noi)*.03))warnings.push(`Reported NOI (${Math.round(noi).toLocaleString()}) differs from gross minus expenses (${Math.round(calc).toLocaleString()}).`)}
  if(type==='Rent Roll'&&!('units' in fields)) warnings.push('No clear total unit/site count was detected in the rent roll.')
  const questions=[]
  if(gross===null)questions.push('Can you provide a breakdown of total revenue for the most recent 12 months?')
  if(expenses===null)questions.push('Can you provide the complete operating expense detail for the same period?')
  if(type==='Rent Roll')questions.push('Please confirm current occupancy, delinquency, concessions, and any month-to-month tenants.')
  if(type==='P&L'||type==='T-12')questions.push('Are there any owner-paid, one-time, or personal expenses that should be normalized?')
  return {mode:'local-extraction',documentType:type,fields,warnings,questions,excerpt:clean.slice(0,5000),confidence:Object.keys(fields).length>=2?'medium':'low'}
}
async function extractDocumentText(filePath,name=''){
  const ext=path.extname(name||filePath).toLowerCase()
  if(['.txt','.csv','.tsv','.json','.md'].includes(ext)) return fs.readFileSync(filePath,'utf8')
  if(ext==='.xlsx'||ext==='.xls'){
    try{const mod=await import('xlsx');const XLSX=mod.default||mod;const wb=XLSX.readFile(filePath);return wb.SheetNames.map(n=>`# ${n}\n${XLSX.utils.sheet_to_csv(wb.Sheets[n])}`).join('\n\n')}
    catch{return ''}
  }
  if(ext==='.pdf'){
    try{const mod=await import('pdf-parse');const pdfParse=mod.default||mod;const out=await pdfParse(fs.readFileSync(filePath));return out.text||''}
    catch{return ''}
  }
  return ''
}

const b64urlDecode = s => Buffer.from(String(s||'').replace(/-/g,'+').replace(/_/g,'/'),'base64').toString('utf8')
const b64urlEncode = s => Buffer.from(String(s||''),'utf8').toString('base64').replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')
const headerValue = (headers,name) => (headers||[]).find(h=>String(h.name).toLowerCase()===name.toLowerCase())?.value||''
function gmailBody(payload){
  if(!payload) return ''
  const mime=String(payload.mimeType||'')
  if(payload.body?.data && (mime==='text/plain'||!payload.parts)) return b64urlDecode(payload.body.data)
  const parts=payload.parts||[]
  for(const part of parts){if(part.mimeType==='text/plain'&&part.body?.data)return b64urlDecode(part.body.data)}
  for(const part of parts){const nested=gmailBody(part);if(nested)return nested}
  if(payload.body?.data) return b64urlDecode(payload.body.data).replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim()
  return ''
}
async function refreshGoogleToken(conn){
  if(!conn?.refreshToken) throw new Error('Gmail connection needs to be reconnected')
  const params=new URLSearchParams({client_id:process.env.GOOGLE_CLIENT_ID||'',client_secret:process.env.GOOGLE_CLIENT_SECRET||'',refresh_token:conn.refreshToken,grant_type:'refresh_token'})
  const r=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:params})
  if(!r.ok) throw new Error('Unable to refresh Gmail access')
  const out=await r.json();conn.accessToken=out.access_token;conn.expiresAt=Date.now()+(Number(out.expires_in||3600)-60)*1000;return conn.accessToken
}
async function gmailAccess(conn){return conn?.accessToken&&Number(conn.expiresAt||0)>Date.now()?conn.accessToken:refreshGoogleToken(conn)}
async function gmailFetch(conn,url,options={}){const access=await gmailAccess(conn);const r=await fetch(`https://gmail.googleapis.com/gmail/v1/users/me${url}`,{...options,headers:{Authorization:`Bearer ${access}`,'Content-Type':'application/json',...(options.headers||{})}});if(!r.ok){const t=await r.text();throw new Error(`Gmail request failed (${r.status}): ${t.slice(0,180)}`)}return r.json()}
const extractEmail = v => (String(v||'').match(/<([^>]+)>/)?.[1]||String(v||'')).trim().toLowerCase()
function messageNeedsReply(messages=[]){const ordered=[...messages].sort((a,b)=>String(a.at).localeCompare(String(b.at)));const last=ordered[ordered.length-1];return !!last&&last.direction==='Inbound'}
function followUpInfo(messages=[]){
  const ordered=[...messages].sort((a,b)=>String(a.at).localeCompare(String(b.at)));const last=ordered[ordered.length-1];if(!last)return {due:false,days:0,label:'No activity'}
  if(last.direction==='Inbound')return {due:false,days:0,label:'Reply needed'}
  const days=Math.max(0,Math.floor((Date.now()-new Date(last.at).getTime())/86400000));return {due:days>=3,days,label:days>=3?`Follow up · ${days} days`:`Last sent · ${days} days`}
}
function conversationQuestions(messages=[]){
  const inbound=messages.filter(m=>m.direction==='Inbound').slice(-8);const qs=[]
  for(const m of inbound){for(const sentence of String(m.body||'').split(/(?<=[?.!])\s+/)){if(sentence.includes('?')&&sentence.length<260)qs.push(sentence.trim())}}
  return [...new Set(qs)].slice(-6)
}

const responseText = data => data?.output_text || (data?.output||[]).flatMap(o=>o.content||[]).map(c=>c.text||'').join('\n').trim()
async function callOpenAI(prompt){
  if(!process.env.OPENAI_API_KEY) return null
  const r=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'Authorization':`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.OPENAI_MODEL||'gpt-5.6-luna',input:prompt})})
  if(!r.ok) throw new Error(`AI request failed (${r.status})`)
  return responseText(await r.json())
}
async function analyzeDocument(doc,deal,analysis){
  if(!doc.storedName) return {mode:'none',fields:{},warnings:['No stored file is available for analysis.'],questions:[],excerpt:'',confidence:'low'}
  const bytes=await blobStore.get(doc.storedName)
  if(!bytes) return {mode:'none',fields:{},warnings:['Document file is missing from storage.'],questions:[],excerpt:'',confidence:'low'}
  const filePath=path.join(os.tmpdir(),`dealflow-${Date.now()}-${sanitizeName(doc.name)}`)
  fs.writeFileSync(filePath,bytes)
  let text=''
  try{text=await extractDocumentText(filePath,doc.name)}finally{try{fs.unlinkSync(filePath)}catch{}}
  let insight=summarizeTextLocally(text,doc.type)
  if(process.env.OPENAI_API_KEY && text){
    const prompt=`You are a real-estate acquisition document analyst. Extract only facts supported by the supplied document. Return VALID JSON only with this shape: {"fields":{"gross":number|null,"expenses":number|null,"noi":number|null,"occupancy":number|null,"rent":number|null,"units":number|null},"warnings":[string],"questions":[string],"summary":string,"confidence":"low|medium|high"}. Document type: ${doc.type}. Property: ${deal.name}. Current underwriting: ${JSON.stringify(analysis||{})}. Document text:\n${text.slice(0,60000)}`
    try{const out=await callOpenAI(prompt);const parsed=JSON.parse(String(out).replace(/^```json\s*|```$/g,'').trim());insight={...parsed,mode:'openai',excerpt:text.slice(0,5000)}}catch(e){insight.aiError=e.message}
  }
  const discrepancies=[]
  const current=analysis||{}
  for(const [key,label] of [['gross','Gross income'],['expenses','Operating expenses']]){
    const v=insight.fields?.[key],cur=current[key]
    if(Number.isFinite(v)&&Number.isFinite(cur)&&cur!==0){const diff=v-cur,pct=Math.abs(diff)/Math.abs(cur)*100;if(pct>=5)discrepancies.push(`${label} in this document is ${pct.toFixed(1)}% ${diff>0?'higher':'lower'} than the current underwriting.`)}
  }
  insight.discrepancies=discrepancies
  return insight
}


const betaPlans = {
  beta: {id:'beta',name:'Beta',price:0,description:'Private beta access',features:['Core deal rooms','Underwriting','Document intelligence','Deal AI','Outreach pipeline']},
  starter: {id:'starter',name:'Starter',price:29,description:'For investors actively working deals',features:['Up to 25 active deals','Document intelligence','Deal AI','Email workflows','Investor share links']},
  pro: {id:'pro',name:'Pro',price:79,description:'For serious acquisition pipelines',features:['Unlimited active deals','Bulk outreach','Advanced Deal AI','Priority document analysis','Team-ready infrastructure']}
}
const stripeRequest=async(pathname,params={})=>{
  if(!process.env.STRIPE_SECRET_KEY) throw new Error('Stripe is not configured on this server.')
  const form=new URLSearchParams(); for(const [k,v] of Object.entries(params)){ if(v!==undefined&&v!==null) form.append(k,String(v)) }
  const r=await fetch(`https://api.stripe.com/v1${pathname}`,{method:'POST',headers:{Authorization:`Bearer ${process.env.STRIPE_SECRET_KEY}`,'Content-Type':'application/x-www-form-urlencoded'},body:form})
  const j=await r.json(); if(!r.ok) throw new Error(j?.error?.message||'Stripe request failed'); return j
}
const syncStripeUser=async(user)=>{
  if(!process.env.STRIPE_SECRET_KEY||!user?.stripeCustomerId) return user
  const r=await fetch(`https://api.stripe.com/v1/subscriptions?customer=${encodeURIComponent(user.stripeCustomerId)}&status=all&limit=5`,{headers:{Authorization:`Bearer ${process.env.STRIPE_SECRET_KEY}`}})
  if(!r.ok) return user; const j=await r.json(); const sub=(j.data||[]).find(x=>['active','trialing','past_due'].includes(x.status))||(j.data||[])[0]
  if(sub){const priceId=sub.items?.data?.[0]?.price?.id;const plan=priceId===process.env.STRIPE_PRICE_PRO?'pro':priceId===process.env.STRIPE_PRICE_STARTER?'starter':user.plan||'beta';user.plan=plan;user.subscriptionStatus=sub.status;user.stripeSubscriptionId=sub.id}
  return user
}

const server=http.createServer(async(req,res)=>{
  const origin=String(req.headers.origin||'')
  if(req.method==='OPTIONS'){const allow=corsOrigin(origin);res.writeHead(204,{...(allow?{'Access-Control-Allow-Origin':allow}:{}),'Vary':'Origin','Access-Control-Allow-Headers':'Content-Type,Authorization','Access-Control-Allow-Methods':'GET,POST,PUT,PATCH,DELETE,OPTIONS',...securityHeaders});return res.end()}
  const url=new URL(req.url,'http://localhost'), p=url.pathname.split('/').filter(Boolean)
  if(p[0]!=='api'){
    if(req.method==='GET'&&fs.existsSync(distDir)){const requested=url.pathname==='/'?'index.html':url.pathname.replace(/^\//,'');let file=path.normalize(path.join(distDir,requested));if(!file.startsWith(distDir))return send(res,403,{error:'Forbidden'},{},origin);if(!fs.existsSync(file)||fs.statSync(file).isDirectory())file=path.join(distDir,'index.html');if(fs.existsSync(file)){const ext=path.extname(file),types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.ico':'image/x-icon'};res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream','Cache-Control':ext==='.html'?'no-cache':'public, max-age=31536000, immutable',...securityHeaders});return fs.createReadStream(file).pipe(res)}}
    return send(res,404,{error:'Not found'},{},origin)
  }
  try{
    const db=await readDB(); db.users ||= []; db.sessions ||= {}; db.investorShares ||= {}; db.offers ||= {}; db.emailConnections ||= {}; db.oauthStates ||= {}; db.leads ||= []; db.savedSearches ||= []; db.outreachCampaigns ||= []; db.feedback ||= []; db.clientErrors ||= []
    if(req.method==='GET'&&p[1]==='health') return send(res,200,{ok:true,version:'1.0.0-beta',database:storageMode(),blobStorage:blobStorageMode(),environment:isProd?'production':'development'},{},origin)
    if(req.method==='POST'&&p[1]==='auth'&&p[2]==='register'){if(!rateLimit(req,'register',10,15*60_000))return send(res,429,{error:'Too many registration attempts. Try again later.'},{},origin);
      const input=await body(req); if(!input.email||!input.password) return send(res,400,{error:'Email and password required'})
      if(db.users.some(u=>u.email.toLowerCase()===input.email.toLowerCase())) return send(res,409,{error:'Email already registered'})
      const {salt,hash}=hashPassword(input.password);const user={id:Date.now(),name:input.name||'Investor',email:input.email.toLowerCase(),salt,hash,plan:'beta',subscriptionStatus:'active',onboardingComplete:false,experienceLevel:'',investmentGoals:[],markets:'',createdAt:new Date().toISOString()};db.users.push(user);const token=createSession(db,user.id);await writeDB(db);return send(res,201,{token,user:safeUser(user)})
    }
    if(req.method==='POST'&&p[1]==='auth'&&p[2]==='login'){if(!rateLimit(req,'login',20,15*60_000))return send(res,429,{error:'Too many login attempts. Try again later.'},{},origin);
      const input=await body(req);const user=db.users.find(u=>u.email===String(input.email||'').toLowerCase());if(!user)return send(res,401,{error:'Invalid login'})
      const {hash}=hashPassword(input.password||'',user.salt);if(hash!==user.hash)return send(res,401,{error:'Invalid login'});const token=createSession(db,user.id);await writeDB(db);return send(res,200,{token,user:safeUser(user)})
    }
    if(req.method==='GET'&&p[1]==='auth'&&p[2]==='me'){const user=userFromReq(req,db);return user?send(res,200,safeUser(user)):send(res,401,{error:'Not signed in'})}
    if(req.method==='POST'&&p[1]==='auth'&&p[2]==='logout'){const token=sessionToken(req);if(token&&db.sessions[token]){delete db.sessions[token];await writeDB(db)}return send(res,200,{ok:true})}

    if(req.method==='GET'&&p[1]==='share'&&p[2]){
      const share=db.investorShares[p[2]];if(!share)return send(res,404,{error:'Share link not found'});const deal=db.deals.find(d=>d.id===share.dealId);const analysis=db.analyses[String(share.dealId)]||null;return send(res,200,{share,deal,analysis,scenarios:db.scenarios[String(share.dealId)]||[]})
    }

    if(req.method==='GET'&&p[1]==='email'&&p[2]==='google'&&p[3]==='callback'){
      const code=url.searchParams.get('code'),state=url.searchParams.get('state'),rec=db.oauthStates[state];
      if(!code||!rec) return send(res,400,{error:'Invalid Gmail connection request'})
      const redirectUri=process.env.GOOGLE_REDIRECT_URI||'http://localhost:8787/api/email/google/callback'
      const params=new URLSearchParams({code,client_id:process.env.GOOGLE_CLIENT_ID||'',client_secret:process.env.GOOGLE_CLIENT_SECRET||'',redirect_uri:redirectUri,grant_type:'authorization_code'})
      const tr=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:params});if(!tr.ok)return send(res,400,{error:'Google token exchange failed'})
      const tok=await tr.json();const conn={provider:'gmail',accessToken:tok.access_token,refreshToken:tok.refresh_token,expiresAt:Date.now()+(Number(tok.expires_in||3600)-60)*1000,scope:tok.scope||'',connectedAt:new Date().toISOString()}
      try{const pr=await fetch('https://gmail.googleapis.com/gmail/v1/users/me/profile',{headers:{Authorization:`Bearer ${tok.access_token}`}});if(pr.ok){const profile=await pr.json();conn.email=profile.emailAddress}}
      catch{}
      db.emailConnections[String(rec.userId)]=conn;delete db.oauthStates[state];await writeDB(db);const app=process.env.APP_ORIGIN||'http://localhost:5173';res.writeHead(302,{Location:`${app}/?gmail=connected`});return res.end()
    }

    const user=userFromReq(req,db)

    if(req.method==='PATCH'&&p[1]==='profile'){
      if(!user)return send(res,401,{error:'Sign in required'});const input=await body(req);if(input.name)user.name=String(input.name).slice(0,120);if(input.experienceLevel!==undefined)user.experienceLevel=String(input.experienceLevel).slice(0,80);if(Array.isArray(input.investmentGoals))user.investmentGoals=input.investmentGoals.slice(0,20).map(x=>String(x).slice(0,80));if(input.markets!==undefined)user.markets=String(input.markets).slice(0,500);if(input.onboardingComplete!==undefined)user.onboardingComplete=!!input.onboardingComplete;await writeDB(db);return send(res,200,safeUser(user))
    }
    if(req.method==='GET'&&p[1]==='billing'&&p[2]==='plans')return send(res,200,{plans:Object.values(betaPlans),stripeConfigured:!!process.env.STRIPE_SECRET_KEY})
    if(req.method==='POST'&&p[1]==='billing'&&p[2]==='checkout'){
      if(!user)return send(res,401,{error:'Sign in required'});const input=await body(req),plan=String(input.plan||'starter');const price=plan==='pro'?process.env.STRIPE_PRICE_PRO:process.env.STRIPE_PRICE_STARTER;if(!price)return send(res,400,{error:'This plan price is not configured yet.'});const base=process.env.APP_ORIGIN||'http://localhost:5173';const params={'mode':'subscription','line_items[0][price]':price,'line_items[0][quantity]':1,'success_url':`${base}/?checkout=success&session_id={CHECKOUT_SESSION_ID}`,'cancel_url':`${base}/?checkout=cancelled`,'client_reference_id':user.id,'customer_email':user.stripeCustomerId?undefined:user.email,'metadata[userId]':user.id};if(user.stripeCustomerId)params.customer=user.stripeCustomerId;const session=await stripeRequest('/checkout/sessions',params);return send(res,200,{url:session.url})
    }
    if(req.method==='POST'&&p[1]==='billing'&&p[2]==='complete'){
      if(!user)return send(res,401,{error:'Sign in required'});const input=await body(req),sid=String(input.sessionId||'');if(!sid)return send(res,400,{error:'Missing checkout session'});if(!process.env.STRIPE_SECRET_KEY)return send(res,400,{error:'Stripe is not configured'});const r=await fetch(`https://api.stripe.com/v1/checkout/sessions/${encodeURIComponent(sid)}`,{headers:{Authorization:`Bearer ${process.env.STRIPE_SECRET_KEY}`}});const j=await r.json();if(!r.ok)return send(res,400,{error:j?.error?.message||'Unable to verify checkout'});if(String(j.client_reference_id||j.metadata?.userId||'')!==String(user.id))return send(res,403,{error:'Checkout session does not belong to this account'});user.stripeCustomerId=typeof j.customer==='string'?j.customer:user.stripeCustomerId;await syncStripeUser(user);await writeDB(db);return send(res,200,safeUser(user))
    }
    if(req.method==='POST'&&p[1]==='billing'&&p[2]==='sync'){
      if(!user)return send(res,401,{error:'Sign in required'});await syncStripeUser(user);await writeDB(db);return send(res,200,safeUser(user))
    }
    if(req.method==='POST'&&p[1]==='billing'&&p[2]==='portal'){
      if(!user)return send(res,401,{error:'Sign in required'});if(!user.stripeCustomerId)return send(res,400,{error:'No billing customer exists for this account yet.'});const base=process.env.APP_ORIGIN||'http://localhost:5173';const session=await stripeRequest('/billing_portal/sessions',{customer:user.stripeCustomerId,return_url:`${base}/?billing=returned`});return send(res,200,{url:session.url})
    }
    if(req.method==='POST'&&p[1]==='feedback'){
      if(!user)return send(res,401,{error:'Sign in required'});const input=await body(req);const row={id:Date.now(),userId:user.id,email:user.email,rating:Number(input.rating||0),category:String(input.category||'General').slice(0,80),message:String(input.message||'').slice(0,10000),page:String(input.page||'').slice(0,120),createdAt:new Date().toISOString()};db.feedback.unshift(row);await writeDB(db);return send(res,201,row)
    }
    if(req.method==='POST'&&p[1]==='client-errors'){
      const input=await body(req);const row={id:Date.now(),userId:user?.id||null,email:user?.email||null,message:String(input.message||'Client error').slice(0,5000),stack:String(input.stack||'').slice(0,15000),page:String(input.page||'').slice(0,200),userAgent:String(req.headers['user-agent']||'').slice(0,500),createdAt:new Date().toISOString()};db.clientErrors.unshift(row);db.clientErrors=db.clientErrors.slice(0,1000);await writeDB(db);return send(res,201,{ok:true})
    }
    if(p[1]==='admin'){
      if(!user||!isAdmin(user))return send(res,403,{error:'Admin access required'});
      if(req.method==='GET'&&p[2]==='overview'){const users=db.users.map(safeUser);return send(res,200,{users:users.length,deals:db.deals.length,leads:db.leads.length,documents:db.documents.length,messages:db.messages.length,feedback:db.feedback.length,errors:db.clientErrors.length,subscriptions:{beta:users.filter(x=>x.plan==='beta').length,starter:users.filter(x=>x.plan==='starter').length,pro:users.filter(x=>x.plan==='pro').length},recentUsers:users.slice(-10).reverse(),recentFeedback:db.feedback.slice(0,20),recentErrors:db.clientErrors.slice(0,20)})}
    }


    if(req.method==='GET'&&p[1]==='email'&&p[2]==='google'&&p[3]==='status'){
      if(!user)return send(res,401,{error:'Sign in required'});const conn=db.emailConnections[String(user.id)];return send(res,200,{connected:!!conn,email:conn?.email||null,configured:!!(process.env.GOOGLE_CLIENT_ID&&process.env.GOOGLE_CLIENT_SECRET)})
    }
    if(req.method==='POST'&&p[1]==='email'&&p[2]==='google'&&p[3]==='start'){
      if(!user)return send(res,401,{error:'Sign in required'});if(!process.env.GOOGLE_CLIENT_ID||!process.env.GOOGLE_CLIENT_SECRET)return send(res,400,{error:'Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET on the server first.'})
      const state=crypto.randomBytes(18).toString('hex');db.oauthStates[state]={userId:user.id,createdAt:Date.now()};await writeDB(db)
      const redirectUri=process.env.GOOGLE_REDIRECT_URI||'http://localhost:8787/api/email/google/callback';const qs=new URLSearchParams({client_id:process.env.GOOGLE_CLIENT_ID,redirect_uri:redirectUri,response_type:'code',access_type:'offline',prompt:'consent',scope:'https://www.googleapis.com/auth/gmail.readonly https://www.googleapis.com/auth/gmail.send',state});return send(res,200,{authUrl:`https://accounts.google.com/o/oauth2/v2/auth?${qs}`})
    }
    if(req.method==='POST'&&p[1]==='email'&&p[2]==='google'&&p[3]==='disconnect'){
      if(!user)return send(res,401,{error:'Sign in required'});delete db.emailConnections[String(user.id)];await writeDB(db);return send(res,200,{ok:true})
    }


    if(req.method==='GET'&&p[1]==='leads'&&p.length===2){
      const rows=db.leads.filter(x=>!x.userId||x.userId===user?.id).map(x=>({...x,fit:leadFit(x)})).sort((a,b)=>b.fit.score-a.fit.score);return send(res,200,rows)
    }
    if(req.method==='POST'&&p[1]==='leads'&&p.length===2){
      const input=await body(req),id=Date.now();const lead={id,userId:user?.id||null,title:input.title||input.name||'Imported Listing',location:input.location||'',type:input.type||'Property',price:Number(input.price||input.asking||0),units:Number(input.units||1),gross:Number(input.gross||0),expenses:Number(input.expenses||0),sourceUrl:input.sourceUrl||input.url||'',source:input.source||'Manual Import',seller:input.seller||'',sellerEmail:input.sellerEmail||'',description:input.description||'',financingNotes:input.financingNotes||'',status:'New Lead',createdAt:new Date().toISOString()};lead.fit=leadFit(lead);db.leads.unshift(lead);await writeDB(db);return send(res,201,lead)
    }
    if(req.method==='POST'&&p[1]==='leads'&&p[2]&&p[3]==='convert'){
      const lead=db.leads.find(x=>x.id===Number(p[2])&&(!x.userId||x.userId===user?.id));if(!lead)return send(res,404,{error:'Lead not found'});const id=Date.now();const deal={id,userId:user?.id||null,name:lead.title,location:lead.location,type:lead.type,asking:Number(lead.price||250000),units:Number(lead.units||1),gross:Number(lead.gross||0),expenses:Number(lead.expenses||0),status:'New Lead',seller:lead.seller||'Add contact',sellerEmail:lead.sellerEmail||'',listingUrl:lead.sourceUrl||'',nextAction:'Verify listing claims, seller motivation, income, expenses, and financing flexibility.'};db.deals.unshift(deal);db.due[String(id)]=starterDue.map((name,i)=>({id:i+1,name,done:false}));db.scenarios[String(id)]=[];lead.status='Converted';lead.convertedDealId=id;await writeDB(db);return send(res,201,deal)
    }
    if(req.method==='GET'&&p[1]==='searches') return send(res,200,db.savedSearches.filter(x=>x.userId===user?.id))
    if(req.method==='POST'&&p[1]==='searches'){
      const input=await body(req),rec={id:Date.now(),userId:user?.id||null,name:input.name||'Saved Search',query:input.query||'',propertyType:input.propertyType||'',maxPrice:Number(input.maxPrice||0),minUnits:Number(input.minUnits||0),radius:Number(input.radius||0),location:input.location||'',creativeFinance:!!input.creativeFinance,createdAt:new Date().toISOString()};db.savedSearches.unshift(rec);await writeDB(db);return send(res,201,rec)
    }



    if(req.method==='POST'&&p[1]==='outreach'&&p[2]==='sync'){
      if(!user)return send(res,401,{error:'Sign in required'});const conn=db.emailConnections[String(user.id)];if(!conn)return send(res,400,{error:'Connect Gmail before syncing outreach replies.'});let replies=0
      for(const campaign of db.outreachCampaigns.filter(c=>c.userId===user.id)){
        for(const item of (campaign.items||[]).filter(i=>i.gmailThreadId&&i.status==='Sent')){
          const th=await gmailFetch(conn,`/threads/${item.gmailThreadId}?format=full`);const sentMs=Date.parse(item.sentAt||0)||0;let latest=null
          for(const gm of (th.messages||[])){const from=headerValue(gm.payload?.headers,'From'),fromEmail=extractEmail(from),internal=Number(gm.internalDate||0);if(fromEmail!==String(conn.email||'').toLowerCase()&&internal>sentMs&&(!latest||internal>latest.internal)){latest={gm,from,internal}}}
          if(latest){item.reply=gmailBody(latest.gm.payload).slice(0,50000);item.status='Replied';item.repliedAt=new Date(latest.internal).toISOString();item.gmailReplyId=latest.gm.id;const lead=db.leads.find(l=>l.id===item.leadId);if(lead){lead.status=outreachStage('Inbound',item.reply,lead.status);lead.lastReplyAt=item.repliedAt;lead.nextFollowUpAt=null}replies++}
        }
      }
      await writeDB(db);return send(res,200,{replies,campaigns:db.outreachCampaigns.filter(c=>c.userId===user.id).map(c=>({...c,stats:campaignStats(c)}))})
    }

    if(req.method==='GET'&&p[1]==='outreach'&&p.length===2){
      if(!user)return send(res,401,{error:'Sign in required'});const rows=db.outreachCampaigns.filter(c=>c.userId===user.id).map(c=>({...c,stats:campaignStats(c)}));return send(res,200,rows)
    }
    if(req.method==='POST'&&p[1]==='outreach'&&p[2]==='draft'){
      if(!user)return send(res,401,{error:'Sign in required'});const input=await body(req),ids=(input.leadIds||[]).map(Number),leads=db.leads.filter(l=>ids.includes(l.id)&&(!l.userId||l.userId===user.id));if(!leads.length)return send(res,400,{error:'Select at least one lead'})
      const followUpDays=Math.max(1,Number(input.followUpDays||3));const campaign={id:Date.now(),userId:user.id,name:input.name||`Outreach ${new Date().toLocaleDateString()}`,goal:input.goal||'Introduce me and ask whether the seller is open to discussing terms.',followUpDays,createdAt:new Date().toISOString(),items:[]}
      let offset=0;for(const lead of leads){const item={id:Date.now()+(++offset),leadId:lead.id,to:lead.sellerEmail||'',contact:lead.seller||'Seller / Broker',subject:`${lead.title} — acquisition inquiry`,body:personalizeOutreach(lead,campaign.goal),status:'Drafted',createdAt:new Date().toISOString(),sentAt:null,followUpAt:null,reply:null};campaign.items.push(item);if(lead.status==='New Lead')lead.status='Drafted'}
      db.outreachCampaigns.unshift(campaign);await writeDB(db);return send(res,201,{...campaign,stats:campaignStats(campaign)})
    }
    if(p[1]==='outreach'&&p[2]&&p[3]==='items'&&p[4]){
      if(!user)return send(res,401,{error:'Sign in required'});const campaign=db.outreachCampaigns.find(c=>c.id===Number(p[2])&&c.userId===user.id);if(!campaign)return send(res,404,{error:'Campaign not found'});const item=campaign.items.find(i=>i.id===Number(p[4]));if(!item)return send(res,404,{error:'Outreach item not found'});const lead=db.leads.find(l=>l.id===item.leadId)
      if(req.method==='PATCH'&&p.length===5){Object.assign(item,await body(req));await writeDB(db);return send(res,200,item)}
      if(req.method==='POST'&&p[5]==='send'){
        if(!rateLimit(req,'outreach-send',60,60*60_000))return send(res,429,{error:'Hourly outreach send limit reached.'},{},origin);
        const input=await body(req);if(input.body)item.body=String(input.body);if(input.subject)item.subject=String(input.subject);if(input.to)item.to=String(input.to);if(!item.to)return send(res,400,{error:'Seller/broker email is required before sending.'});const conn=db.emailConnections[String(user.id)];if(!conn)return send(res,400,{error:'Connect Gmail before sending outreach.'})
        const raw=`To: ${item.to}\r\nSubject: ${item.subject}\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n${item.body}`;const out=await gmailFetch(conn,'/messages/send',{method:'POST',body:JSON.stringify({raw:b64urlEncode(raw)})});item.status='Sent';item.sentAt=new Date().toISOString();item.gmailMessageId=out.id;item.gmailThreadId=out.threadId;item.followUpAt=new Date(Date.now()+campaign.followUpDays*86400000).toISOString();if(lead){lead.status=outreachStage('Outbound',item.body,lead.status);lead.lastContactAt=item.sentAt;lead.nextFollowUpAt=item.followUpAt}await writeDB(db);return send(res,200,{item,lead,stats:campaignStats(campaign)})
      }
      if(req.method==='POST'&&p[5]==='reply'){
        const input=await body(req);item.reply=String(input.body||'');item.status='Replied';item.repliedAt=new Date().toISOString();if(lead){lead.status=outreachStage('Inbound',item.reply,lead.status);lead.lastReplyAt=item.repliedAt;lead.nextFollowUpAt=null}await writeDB(db);return send(res,200,{item,lead,stats:campaignStats(campaign)})
      }
      if(req.method==='POST'&&p[5]==='followup-draft'){
        const first=String(item.contact||'').trim().split(/\s+/)[0]||'there';item.followUpDraft=`Hi ${first},\n\nJust following up on my note about ${lead?.title||'the property'}. I’m still interested and wanted to see if you had a chance to review it. If the property is still available, I’d be glad to discuss price, timing, and any financing terms that matter most to the seller.\n\nThanks,`;return send(res,200,item)
      }
    }

    if(req.method==='GET'&&p[1]==='deals'&&p.length===2) return send(res,200,db.deals.filter(d=>ownsDeal(d,user)))
    if(req.method==='POST'&&p[1]==='deals'&&p.length===2){
      const input=await body(req),id=Date.now();const deal={id,userId:user?.id||null,name:input.name||'New Investment Property',location:input.location||'Add location',type:input.type||'Property',asking:Number(input.asking||250000),units:Number(input.units||1),gross:Number(input.gross||30000),expenses:Number(input.expenses||12000),status:'New Lead',seller:input.seller||'Add contact',nextAction:'Add the listing details and verify income and expenses.'};db.deals.unshift(deal);db.due[String(id)]=starterDue.map((name,i)=>({id:i+1,name,done:false}));db.scenarios[String(id)]=[];await writeDB(db);return send(res,201,deal)
    }
    if(p[1]==='deals'&&p[2]){
      const id=Number(p[2]), deal=db.deals.find(d=>d.id===id);if(!deal||!ownsDeal(deal,user))return send(res,404,{error:'Deal not found'})
      if(req.method==='GET'&&p.length===3)return send(res,200,{deal,analysis:db.analyses[String(id)]||null,documents:db.documents.filter(x=>x.dealId===id),messages:db.messages.filter(x=>x.dealId===id),due:db.due[String(id)]||[],scenarios:db.scenarios[String(id)]||[],offers:db.offers[String(id)]||[],communication:{needsReply:messageNeedsReply(db.messages.filter(x=>x.dealId===id)),unansweredQuestions:conversationQuestions(db.messages.filter(x=>x.dealId===id)),followUp:followUpInfo(db.messages.filter(x=>x.dealId===id))}})
      if(req.method==='GET'&&p[3]==='documents'&&p[4]&&p[5]==='download'){const doc=db.documents.find(x=>x.dealId===id&&x.id===Number(p[4]));if(!doc||!doc.storedName)return send(res,404,{error:'Document file not found'});const bytes=await blobStore.get(doc.storedName);if(!bytes)return send(res,404,{error:'Document file missing from storage'});res.writeHead(200,{'Content-Type':'application/octet-stream','Content-Length':bytes.length,'Content-Disposition':`attachment; filename="${sanitizeName(doc.name)}"`,...securityHeaders});return res.end(bytes)}
      if(req.method==='PATCH'&&p.length===3){Object.assign(deal,await body(req));await writeDB(db);return send(res,200,deal)}
      if(req.method==='PUT'&&p[3]==='analysis'){db.analyses[String(id)]=await body(req);await writeDB(db);return send(res,200,db.analyses[String(id)])}
      if(req.method==='POST'&&p[3]==='documents'&&p.length===4){
        const input=await body(req);let storedName=null;if(input.base64){const buf=Buffer.from(input.base64,'base64');if(buf.length>10_000_000)return send(res,413,{error:'File exceeds 10 MB'});storedName=`documents/${user?.id||'public'}/${id}/${Date.now()}-${sanitizeName(input.name)}`;await blobStore.put(storedName,buf,input.contentType||'application/octet-stream')}
        const doc={id:Date.now(),dealId:id,name:input.name||'Untitled document',type:input.type||'Other',status:storedName?'Uploaded':'Needs review',note:input.note||'',storedName,size:Number(input.size||0),uploadedAt:new Date().toISOString()};
        if(storedName){doc.insight=await analyzeDocument(doc,deal,db.analyses[String(id)]||{price:deal.asking,down:0,rate:0,amortYears:25,gross:deal.gross,expenses:deal.expenses,vacancy:5});doc.status=doc.insight?.fields&&Object.keys(doc.insight.fields).length?'Analyzed':'Uploaded'}
        db.documents.push(doc);await writeDB(db);return send(res,201,doc)
      }
      if(req.method==='POST'&&p[3]==='documents'&&p[4]&&p[5]==='analyze'){
        const doc=db.documents.find(x=>x.dealId===id&&x.id===Number(p[4]));if(!doc)return send(res,404,{error:'Document not found'});doc.insight=await analyzeDocument(doc,deal,db.analyses[String(id)]||{price:deal.asking,down:0,rate:0,amortYears:25,gross:deal.gross,expenses:deal.expenses,vacancy:5});doc.status=doc.insight?.fields&&Object.keys(doc.insight.fields).length?'Analyzed':'Uploaded';await writeDB(db);return send(res,200,doc)
      }
      if(req.method==='POST'&&p[3]==='documents'&&p[4]&&p[5]==='apply'){
        const doc=db.documents.find(x=>x.dealId===id&&x.id===Number(p[4]));if(!doc)return send(res,404,{error:'Document not found'});const fields=doc.insight?.fields||{};const a=db.analyses[String(id)]||{price:deal.asking,down:0,rate:0,amortYears:25,gross:deal.gross,expenses:deal.expenses,vacancy:5};
        if(Number.isFinite(fields.gross))a.gross=fields.gross;if(Number.isFinite(fields.expenses))a.expenses=fields.expenses;db.analyses[String(id)]=a;
        if(Number.isFinite(fields.units))deal.units=fields.units;doc.appliedAt=new Date().toISOString();await writeDB(db);return send(res,200,{analysis:a,deal})
      }

      if(req.method==='POST'&&p[3]==='email'&&p[4]==='sync'){
        if(!user)return send(res,401,{error:'Sign in required'});const conn=db.emailConnections[String(user.id)];if(!conn)return send(res,400,{error:'Connect Gmail first.'})
        const sellerEmail=String(deal.sellerEmail||'').trim();const q=sellerEmail?`newer_than:180d {from:${sellerEmail} to:${sellerEmail}}`:`newer_than:180d "${deal.name}"`;const list=await gmailFetch(conn,`/threads?maxResults=30&q=${encodeURIComponent(q)}`);let added=0
        for(const t of (list.threads||[])){const th=await gmailFetch(conn,`/threads/${t.id}?format=full`);for(const gm of (th.messages||[])){if(db.messages.some(m=>m.gmailMessageId===gm.id))continue;const from=headerValue(gm.payload?.headers,'From'),to=headerValue(gm.payload?.headers,'To'),subject=headerValue(gm.payload?.headers,'Subject'),fromEmail=extractEmail(from),direction=fromEmail===String(conn.email||'').toLowerCase()?'Outbound':'Inbound';const msg={id:Date.now()+added,dealId:id,contact:direction==='Inbound'?(from||'Seller'):(to||deal.seller),channel:'Gmail',direction,subject,body:gmailBody(gm.payload).slice(0,50000),at:new Date(Number(gm.internalDate||Date.now())).toISOString(),gmailMessageId:gm.id,gmailThreadId:t.id};db.messages.push(msg);added++}}
        await writeDB(db);return send(res,200,{added,total:db.messages.filter(m=>m.dealId===id).length,needsReply:messageNeedsReply(db.messages.filter(m=>m.dealId===id)),unansweredQuestions:conversationQuestions(db.messages.filter(m=>m.dealId===id))})
      }
      if(req.method==='POST'&&p[3]==='messages'&&p[4]==='draft'){
        const msgs=db.messages.filter(m=>m.dealId===id).sort((a,b)=>String(a.at).localeCompare(String(b.at))).slice(-20);const input=await body(req);const goal=String(input.goal||'Write the best concise next reply.');let draft='Thanks for the update. I’m reviewing everything now. Could you also confirm the remaining items and whether there is flexibility in the terms we discussed?'
        if(process.env.OPENAI_API_KEY){try{const out=await callOpenAI(`Draft a concise professional real-estate acquisition email reply. Use the existing thread and do not re-introduce the buyer. Do not invent facts. Goal: ${goal}. Deal: ${JSON.stringify(deal)}. Thread: ${JSON.stringify(msgs)}. Return only the email body.`);if(out)draft=out}catch{}}
        else {const qs=conversationQuestions(msgs);if(qs.length)draft=`Thanks for the update. I’m reviewing the deal now. On your last message, I want to make sure I answer everything clearly. ${qs.map(q=>`Regarding “${q}” — I’ll confirm that as part of my review.`).join(' ')} Also, could you confirm whether the current price and financing terms are still flexible?`}
        return send(res,200,{draft,unansweredQuestions:conversationQuestions(msgs),mode:process.env.OPENAI_API_KEY?'openai':'local'})
      }
      if(req.method==='POST'&&p[3]==='email'&&p[4]==='send'){if(!rateLimit(req,'deal-email-send',60,60*60_000))return send(res,429,{error:'Hourly email send limit reached.'},{},origin);
        if(!user)return send(res,401,{error:'Sign in required'});const conn=db.emailConnections[String(user.id)];if(!conn)return send(res,400,{error:'Connect Gmail first.'});const input=await body(req),to=String(input.to||deal.sellerEmail||'').trim();if(!to)return send(res,400,{error:'Add a seller email first.'});const subject=String(input.subject||`Re: ${deal.name}`),emailBody=String(input.body||'').trim();if(!emailBody)return send(res,400,{error:'Message body required'})
        const raw=`To: ${to}\r\nSubject: ${subject}\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n${emailBody}`;const out=await gmailFetch(conn,'/messages/send',{method:'POST',body:JSON.stringify({raw:b64urlEncode(raw),threadId:input.threadId||undefined})});const msg={id:Date.now(),dealId:id,contact:to,channel:'Gmail',direction:'Outbound',subject,body:emailBody,at:new Date().toISOString(),gmailMessageId:out.id,gmailThreadId:out.threadId};db.messages.push(msg);await writeDB(db);return send(res,201,msg)
      }

      if(req.method==='POST'&&p[3]==='messages'){const input=await body(req);const msg={id:Date.now(),dealId:id,contact:input.contact||'Seller',channel:input.channel||'Note',direction:input.direction||'Outbound',subject:input.subject||'',body:input.body||'',at:new Date().toISOString()};db.messages.push(msg);await writeDB(db);return send(res,201,msg)}
      if(req.method==='PATCH'&&p[3]==='due'&&p[4]){const task=(db.due[String(id)]||[]).find(t=>t.id===Number(p[4]));if(!task)return send(res,404,{error:'Task not found'});Object.assign(task,await body(req));await writeDB(db);return send(res,200,task)}
      if(req.method==='POST'&&p[3]==='scenarios'){const input=await body(req);const scenario={id:Date.now(),name:input.name||'Custom Structure',down:Number(input.down||0),rate:Number(input.rate||0),years:Number(input.years||25),note:input.note||''};(db.scenarios[String(id)] ||= []).push(scenario);await writeDB(db);return send(res,201,scenario)}
      if(req.method==='POST'&&p[3]==='share'){const input=await body(req);const token=crypto.randomBytes(10).toString('hex');db.investorShares[token]={token,dealId:id,title:input.title||`${deal.name} Investor Overview`,createdAt:new Date().toISOString(),expiresAt:input.expiresAt||null};await writeDB(db);return send(res,201,db.investorShares[token])}
      if(req.method==='POST'&&p[3]==='offers'){
        const input=await body(req);const offer={id:Date.now(),dealId:id,type:'LOI',buyer:input.buyer||user?.name||'Buyer',seller:input.seller||deal.seller||'Seller',price:Number(input.price||deal.asking),earnest:Number(input.earnest||1000),down:Number(input.down||0),rate:Number(input.rate||0),amortYears:Number(input.amortYears||25),balloonYears:Number(input.balloonYears||5),dueDays:Number(input.dueDays||30),closeDays:Number(input.closeDays||45),createdAt:new Date().toISOString()};(db.offers[String(id)] ||= []).push(offer);await writeDB(db);return send(res,201,offer)
      }
    }
    if(req.method==='POST'&&p[1]==='ai'){
      const input=await body(req),deal=db.deals.find(d=>d.id===Number(input.dealId));if(!deal||!ownsDeal(deal,user))return send(res,404,{error:'Deal not found'});const a=db.analyses[String(deal.id)]||{price:deal.asking,down:0,rate:0,amortYears:25,gross:deal.gross,expenses:deal.expenses,vacancy:5};const docs=db.documents.filter(x=>x.dealId===deal.id).map(d=>({name:d.name,type:d.type,status:d.status,fields:d.insight?.fields||{},discrepancies:d.insight?.discrepancies||[],warnings:d.insight?.warnings||[]}));const due=(db.due[String(deal.id)]||[]);const scenarios=db.scenarios[String(deal.id)]||[];const q=String(input.query||'').trim();
      if(process.env.OPENAI_API_KEY){
        try{const answer=await callOpenAI(`You are DealFlow AI, an assistant inside a real-estate acquisition platform. Be concise, practical, and distinguish verified facts from assumptions. Do not claim legal, tax, securities, appraisal, lending, or inspection conclusions. Property: ${JSON.stringify(deal)}. Current underwriting: ${JSON.stringify(a)}. Uploaded document findings: ${JSON.stringify(docs)}. Due diligence: ${JSON.stringify(due)}. Financing scenarios: ${JSON.stringify(scenarios)}. User question: ${q}`);if(answer)return send(res,200,{answer,mode:'openai'})}catch(e){/* fall through to local rules */}
      }
      const lower=q.toLowerCase(),noi=a.gross*(1-a.vacancy/100)-a.expenses;let answer=`For ${deal.name}, verify income, operating expenses, financing terms, and seller motivation before increasing commitment.`;if(lower.includes('next'))answer=deal.nextAction;else if(lower.includes('seller'))answer='Confirm the seller’s required cash at closing, whether price is flexible, and which terms matter most: down payment, rate, amortization, or balloon.';else if(lower.includes('document')||lower.includes('missing')){const missing=due.filter(x=>!x.done).slice(0,5).map(x=>x.name);const flagged=docs.flatMap(d=>d.discrepancies||[]).slice(0,3);answer=(missing.length?`Still missing or unverified: ${missing.join(', ')}. `:'The current due-diligence checklist is complete. ')+(flagged.length?`Document flags: ${flagged.join(' ')}`:'')}else if(lower.includes('cash flow'))answer=`Current estimated NOI is about $${Math.round(noi).toLocaleString()} before debt service.`;else if(lower.includes('difference')||lower.includes('discrep')){const flagged=docs.flatMap(d=>d.discrepancies||[]);answer=flagged.length?flagged.join(' '):'No material document-to-underwriting differences are currently flagged.'}return send(res,200,{answer,mode:'local-rules'})
    }
    return send(res,404,{error:'Unknown endpoint'})
  }catch(e){console.error('[DealFlow]',e);return send(res,500,{error:isProd?'Internal server error':e.message},{},origin)}
})
const port=Number(process.env.PORT||8787)
const host=process.env.HOST||'0.0.0.0'
server.listen(port,host,()=>console.log(`DealFlow v1.0 beta running on ${host}:${port} · DB ${storageMode()} · Files ${blobStorageMode()}`))
