#!/bin/sh
set -eu
DATA_DIR="${DATA_DIR:-./data}"
UPLOAD_DIR="${UPLOAD_DIR:-./uploads}"
OUT="${1:-./backups}"
mkdir -p "$OUT"
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
tar -czf "$OUT/dealflow-$STAMP.tgz" "$DATA_DIR" "$UPLOAD_DIR"
echo "$OUT/dealflow-$STAMP.tgz"
